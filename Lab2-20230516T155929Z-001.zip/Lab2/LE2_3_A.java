public class Main{
    public static void main(String args[]){
        Mother m1=new Child();
        m1.show();
    }
}