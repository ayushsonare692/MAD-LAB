public class Mother{
    int x;
    void show(){
        System.out.println("Mother is called");
    }
}