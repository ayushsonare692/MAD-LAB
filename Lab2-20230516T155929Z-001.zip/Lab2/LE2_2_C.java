public class Child extends Parent{
    public void show(){
        System.out.println("Hello JUET");
    }
}