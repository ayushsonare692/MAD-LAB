public class Parent{
    public void show(){
        System.out.println("Hello World");
    }
}