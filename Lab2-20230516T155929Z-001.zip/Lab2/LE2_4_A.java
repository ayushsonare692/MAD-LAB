public class Main{
    public static void main(String args[])
    {
        One o=new One(2);
        Two t=new Two(4);
        o.show();
        t.show();
        
    }
}