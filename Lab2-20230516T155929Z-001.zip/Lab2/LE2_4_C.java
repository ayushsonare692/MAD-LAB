public class Two extends One{
    Two(int c){
        super(c);
    }
}