public class One{
    int x;
    One(int a)
    {
        x=a;
    }
    public void show(){
        System.out.println(x);
    }
}