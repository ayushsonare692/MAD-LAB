interface Flyable{
    void fly();
}