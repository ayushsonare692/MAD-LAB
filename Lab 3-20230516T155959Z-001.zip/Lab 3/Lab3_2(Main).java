
public class Main
{
	public static void main(String[] args) {
		//Testable Te=new Test(); Comment: Testtable is 100% or pure abstract class so we can not make a object of it. 
		Test T=new Test();
		//AbsTest A=new AbsTest(); Comment: AbsTest is a abstract class so we can not make a object of it.
		T.display();
		
		//A.display();
	}
}
