class RedHeadDucks extends Ducks implements Flyable,Quackable{
    public void quack(){
        System.out.println("Red Head Ducks Quacks");
    }
    public void fly(){
        System.out.println("Red Head Duck FLY");
    }
}