abstract class AbsTest implements Testable{
   public abstract void display();
    
}