class WoodenDucks extends Ducks{

}