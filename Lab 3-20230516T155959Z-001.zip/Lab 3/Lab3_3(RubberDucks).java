class RubberDucks extends Ducks implements Quackable{
    public void quack(){
        System.out.println("Rubber Duck squeaks");
    }
}