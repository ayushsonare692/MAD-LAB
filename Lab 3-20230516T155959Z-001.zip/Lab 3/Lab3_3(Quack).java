interface Quackable{
    void quack();
}