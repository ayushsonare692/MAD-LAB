class Main {
public static void main ( String args[ ]){
    int  i;
    int num=Integer.parseInt(args[0]);
    for(i=1;i<11;i++)
    {
        System.out.println(num+" "+"x"+" "+i+" "+"="+" "+num*i);
    }
}
}
